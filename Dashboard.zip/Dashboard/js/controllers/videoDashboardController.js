//(function(){
    angular.module('dashboard')
    .controller("videoDashboard",function ($scope, $location) {
        $scope.greeting = 'Video Dashboard';
        $scope.pageName = 'Video Dashboard Page';
        //TODO Temporarily commenting
        // if (!sessionStorage.getItem(‘loginId’)) {
        //     $location.path(“/login”);
        // }
        $scope.logoutBtn = true;
        $scope.onLogout = function () {
            $location.path('/login');
            sessionStorage.removeItem('loginId');
        };
        $scope.onGraphBtnClick = function () {
            if (sessionStorage.getItem('loginId'))
            {
                $location.path("/graphs_dashboard")
                ;
            }
        };
        $scope.top4VideosContainer = true;
        $scope.videoGallaryContainer = false;
        $scope.onVideoGallary = function () {
            angular.element(document.getElementById("top4Videos")).addClass("passiveVideoNavigationBtn")
            angular.element(document.getElementById('videoGallary')).removeClass("passiveVideoNavigationBtn")
            $scope.top4VideosContainer = false;
            $scope.videoGallaryContainer = true;

        };
        $scope.onTop4Videos = function () {
            //angular.element(document.getElementById('top4Videos’)).removeClass("passiveVideoNavigationBtn")
            angular.element(document.getElementById('top4Videos')).removeClass('passiveVideoNavigationBtn')
            angular.element(document.getElementById('videoGallary')).addClass('passiveVideoNavigationBtn');
            $scope.top4VideosContainer = true;
            $scope.videoGallaryContainer = false;
        };

        $scope.videos = [
            {
                number: 5
            },
            {
                number: 6
            },
            {
                number: 7
            },
            {
                number: 8
            },
            {
                number: 10
            },
            {
                number: 11
            },
            {
                number: 12
            },
            {
                number: 13
            },
            {
                number: 14
            }
            //,
            //{
            //    number: 9
            //},
            //{
            //    number: 10
            //},
            //{
            //    number: 11
            //},
            //{
            //    number: 12
            //},
            //{
            //    number: 13
            //},
            //{
            //    number: 14
            //},
            //{
            //    number: 15
            //},
            //{
            //    number: 16
            //},
            //{
            //    number: 17
            //},
            //{
            //    number: 18
            //},
            //{
            //    number: 19
            //},
            //{
            //    number: 20
            //}
        ]
    });
//})();
